import numpy as np
import torch
import torch.nn as nn

from torch.utils.data import DataLoader, WeightedRandomSampler
from torch.optim.lr_scheduler import ReduceLROnPlateau
import argparse
import warnings

import os
from tqdm import tqdm
import json
import time

from tabsyn.vae.model import Model_VAE, Encoder_model, Decoder_model
from utils_train import preprocess, TabularDataset

warnings.filterwarnings('ignore')


LR = 1e-3
WD = 0
D_TOKEN = 4
TOKEN_BIAS = True

N_HEAD = 1
FACTOR = 32
NUM_LAYERS = 2


def compute_loss(X_num, X_cat, Recon_X_num, Recon_X_cat, mu_z, logvar_z):
    ce_loss_fn = nn.CrossEntropyLoss()
    mse_loss = (X_num - Recon_X_num).pow(2).mean()
    ce_loss = 0
    acc = 0
    total_num = 0

    for idx, x_cat in enumerate(Recon_X_cat):
        if x_cat is not None:
            ce_loss += ce_loss_fn(x_cat, X_cat[:, idx])
            x_hat = x_cat.argmax(dim = -1)
        acc += (x_hat == X_cat[:,idx]).float().sum()
        total_num += x_hat.shape[0]
    
    ce_loss /= (idx + 1)
    acc /= total_num

    temp = 1 + logvar_z - mu_z.pow(2) - logvar_z.exp()

    loss_kld = -0.5 * torch.mean(temp.mean(-1).mean())
    return mse_loss, ce_loss, loss_kld, acc


def get_class_balanced_sampler(X_cat, target_col_idx, minority_ratio=None):
    """
    Create a weighted sampler for class balancing.
    
    Args:
        X_cat: Categorical features (including target)
        target_col_idx: Index of the target column in X_cat
        minority_ratio: Desired ratio of minority class (e.g., 0.5 for 50:50)
                       If None, use balanced sampling (equal weights)
    
    Returns:
        WeightedRandomSampler
    """
    # Get target labels
    if isinstance(X_cat, torch.Tensor):
        labels = X_cat[:, target_col_idx].numpy()
    else:
        labels = X_cat[:, target_col_idx]
    
    # Count classes
    unique_classes, class_counts = np.unique(labels, return_counts=True)
    n_samples = len(labels)
    
    print(f"\nOriginal class distribution:")
    for cls, count in zip(unique_classes, class_counts):
        print(f"  Class {cls}: {count} ({count/n_samples*100:.2f}%)")
    
    # Calculate weights for each sample
    if minority_ratio is not None:
        # Custom ratio: minority_ratio for minority class, (1-minority_ratio) for majority
        # Assume binary classification: 0 = majority, 1 = minority
        target_ratios = {0: 1.0 - minority_ratio, 1: minority_ratio}
        
        # Calculate weight for each class
        class_weights = {}
        for cls in unique_classes:
            cls = int(cls)
            target_ratio = target_ratios.get(cls, 1.0 / len(unique_classes))
            current_ratio = class_counts[cls] / n_samples
            # Weight inversely proportional to current frequency, scaled to target ratio
            class_weights[cls] = target_ratio / current_ratio
        
        print(f"\nTarget ratio - Majority:Minority = {1-minority_ratio:.2f}:{minority_ratio:.2f}")
    else:
        # Balanced sampling: equal probability for all classes
        class_weights = {int(cls): n_samples / count for cls, count in zip(unique_classes, class_counts)}
        print(f"\nUsing balanced sampling (equal probability for all classes)")
    
    # Assign weight to each sample
    sample_weights = np.array([class_weights[int(label)] for label in labels])
    sample_weights = torch.from_numpy(sample_weights).double()
    
    print(f"Class weights: {class_weights}")
    
    # Create sampler
    sampler = WeightedRandomSampler(
        weights=sample_weights,
        num_samples=len(sample_weights),
        replacement=True
    )
    
    return sampler


def main(args):
    dataname = args.dataname
    data_dir = f'data/{dataname}'

    max_beta = args.max_beta
    min_beta = args.min_beta
    lambd = args.lambd

    device = args.device

    info_path = f'data/{dataname}/info.json'

    with open(info_path, 'r') as f:
        info = json.load(f)

    curr_dir = os.path.dirname(os.path.abspath(__file__))
    ckpt_dir = f'{curr_dir}/ckpt/{dataname}' 
    if not os.path.exists(ckpt_dir):
        os.makedirs(ckpt_dir)

    model_save_path = f'{ckpt_dir}/model.pt'
    encoder_save_path = f'{ckpt_dir}/encoder.pt'
    decoder_save_path = f'{ckpt_dir}/decoder.pt'

    X_num, X_cat, categories, d_numerical = preprocess(data_dir, task_type=info['task_type'])

    X_train_num, X_test_num = X_num
    X_train_cat, X_test_cat = X_cat

    X_train_num, X_test_num = torch.tensor(X_train_num).float(), torch.tensor(X_test_num).float()
    X_train_cat, X_test_cat = torch.tensor(X_train_cat), torch.tensor(X_test_cat)

    train_data = TabularDataset(X_train_num.float(), X_train_cat)

    X_test_num = X_test_num.float().to(device)
    X_test_cat = X_test_cat.to(device)

    batch_size = 4096
    
    # Create class-balanced sampler if ratio is specified
    if args.use_ratio and info['task_type'] in ['binclass', 'multiclass']:
        # Get target column index
        # Assuming target is concatenated to categorical features
        target_col_idx = info.get('target_col_idx', None)
        
        if target_col_idx is not None:
            # If target is separate, need to concatenate first
            # This assumes preprocess() concatenates target to X_cat
            sampler = get_class_balanced_sampler(
                X_train_cat, 
                target_col_idx=-1,  # Assuming target is last column
                minority_ratio=args.minority_ratio_tvae
            )
            
            train_loader = DataLoader(
                train_data,
                batch_size=batch_size,
                sampler=sampler,  # Use weighted sampler instead of shuffle
                num_workers=4,
            )
            print("Using class-balanced sampler for training!")
        else:
            print("Warning: target_col_idx not found, using regular sampling")
            train_loader = DataLoader(
                train_data,
                batch_size=batch_size,
                shuffle=True,
                num_workers=4,
            )
    else:
        train_loader = DataLoader(
            train_data,
            batch_size=batch_size,
            shuffle=True,
            num_workers=4,
        )

    model = Model_VAE(NUM_LAYERS, d_numerical, categories, D_TOKEN, n_head=N_HEAD, factor=FACTOR, bias=True)
    model = model.to(device)

    pre_encoder = Encoder_model(NUM_LAYERS, d_numerical, categories, D_TOKEN, n_head=N_HEAD, factor=FACTOR).to(device)
    pre_decoder = Decoder_model(NUM_LAYERS, d_numerical, categories, D_TOKEN, n_head=N_HEAD, factor=FACTOR).to(device)

    pre_encoder.eval()
    pre_decoder.eval()

    optimizer = torch.optim.Adam(model.parameters(), lr=LR, weight_decay=WD)
    scheduler = ReduceLROnPlateau(optimizer, mode='min', factor=0.95, patience=10)

    num_epochs = 4000
    best_train_loss = float('inf')

    current_lr = optimizer.param_groups[0]['lr']
    patience = 0

    beta = max_beta
    start_time = time.time()
    
    for epoch in range(num_epochs):
        pbar = tqdm(train_loader, total=len(train_loader))
        pbar.set_description(f"Epoch {epoch+1}/{num_epochs}")

        curr_loss_multi = 0.0
        curr_loss_gauss = 0.0
        curr_loss_kl = 0.0

        curr_count = 0
        
        # Track class distribution in batches (for monitoring)
        epoch_class_counts = {}

        for batch_num, batch_cat in pbar:
            model.train()
            optimizer.zero_grad()

            batch_num = batch_num.to(device)
            batch_cat = batch_cat.to(device)
            
            # Monitor class distribution in current batch
            if args.use_ratio and epoch % 100 == 0:
                batch_labels = batch_cat[:, -1].cpu().numpy()
                for label in batch_labels:
                    epoch_class_counts[int(label)] = epoch_class_counts.get(int(label), 0) + 1

            Recon_X_num, Recon_X_cat, mu_z, std_z = model(batch_num, batch_cat)
        
            loss_mse, loss_ce, loss_kld, train_acc = compute_loss(batch_num, batch_cat, Recon_X_num, Recon_X_cat, mu_z, std_z)

            loss = loss_mse + loss_ce + beta * loss_kld
            loss.backward()
            optimizer.step()

            batch_length = batch_num.shape[0]
            curr_count += batch_length
            curr_loss_multi += loss_ce.item() * batch_length
            curr_loss_gauss += loss_mse.item() * batch_length
            curr_loss_kl += loss_kld.item() * batch_length

        num_loss = curr_loss_gauss / curr_count
        cat_loss = curr_loss_multi / curr_count
        kl_loss = curr_loss_kl / curr_count
        
        # Print class distribution every 100 epochs
        if args.use_ratio and epoch % 100 == 0 and epoch_class_counts:
            print(f"\nEpoch {epoch} - Batch class distribution:")
            total_samples = sum(epoch_class_counts.values())
            for cls, count in sorted(epoch_class_counts.items()):
                print(f"  Class {cls}: {count} ({count/total_samples*100:.2f}%)")

        '''
            Evaluation
        '''
        model.eval()
        with torch.no_grad():
            Recon_X_num, Recon_X_cat, mu_z, std_z = model(X_test_num, X_test_cat)

            val_mse_loss, val_ce_loss, val_kl_loss, val_acc = compute_loss(X_test_num, X_test_cat, Recon_X_num, Recon_X_cat, mu_z, std_z)
            val_loss = val_mse_loss.item() * 0 + val_ce_loss.item()    

            scheduler.step(val_loss)
            new_lr = optimizer.param_groups[0]['lr']

            if new_lr != current_lr:
                current_lr = new_lr
                print(f"Learning rate updated: {current_lr}")
                
            train_loss = val_loss
            if train_loss < best_train_loss:
                best_train_loss = train_loss
                patience = 0
                torch.save(model.state_dict(), model_save_path)
            else:
                patience += 1
                if patience == 10:
                    if beta > min_beta:
                        beta = beta * lambd

        print('epoch: {}, beta = {:.6f}, Train MSE: {:.6f}, Train CE:{:.6f}, Train KL:{:.6f}, Val MSE:{:.6f}, Val CE:{:.6f}, Train ACC:{:6f}, Val ACC:{:6f}'.format(
            epoch, beta, num_loss, cat_loss, kl_loss, val_mse_loss.item(), val_ce_loss.item(), train_acc.item(), val_acc.item()))

    end_time = time.time()
    print('Training time: {:.4f} mins'.format((end_time - start_time)/60))
    
    # Saving latent embeddings
    with torch.no_grad():
        pre_encoder.load_weights(model)
        pre_decoder.load_weights(model)

        # 배치 크기 설정
        batch_size = 1024

        # 전체 데이터를 배치로 나눠서 처리
        train_z_list = []

        for i in range(0, len(X_train_num), batch_size):
            batch_num = X_train_num[i:i+batch_size].to(device)
            batch_cat = X_train_cat[i:i+batch_size].to(device)
            
            with torch.no_grad():
                batch_z = pre_encoder(batch_num, batch_cat).detach().cpu().numpy()
            
            train_z_list.append(batch_z)
            
            del batch_num, batch_cat
            torch.cuda.empty_cache()

        train_z = np.concatenate(train_z_list, axis=0)

        np.save(f'{ckpt_dir}/train_z.npy', train_z)

        print('Successfully save pretrained embeddings in disk!')


if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='Variational Autoencoder')

    parser.add_argument('--dataname', type=str, default='adult', help='Name of dataset.')
    parser.add_argument('--gpu', type=int, default=0, help='GPU index.')
    parser.add_argument('--max_beta', type=float, default=1e-2, help='Initial Beta.')
    parser.add_argument('--min_beta', type=float, default=1e-5, help='Minimum Beta.')
    parser.add_argument('--lambd', type=float, default=0.7, help='Decay of Beta.')
    
    # Class balancing arguments
    parser.add_argument('--use_ratio', action='store_true', help='Use class balancing during training.')
    parser.add_argument('--minority_ratio', type=float, default=0.5, 
                        help='Desired ratio of minority class (e.g., 0.5 for 50:50 balance). If not specified, uses equal weights.')

    args = parser.parse_args()

    # check cuda
    if args.gpu != -1 and torch.cuda.is_available():
        args.device = 'cuda:{}'.format(args.gpu)
    else:
        args.device = 'cpu'
    
    main(args)