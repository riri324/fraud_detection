import os
import torch
import numpy as np
from torch.utils.data import DataLoader, TensorDataset, WeightedRandomSampler
from torch.optim.lr_scheduler import ReduceLROnPlateau
import argparse
import warnings
import time
import json
from tqdm import tqdm
from tabsyn.model import MLPDiffusion, Model
from tabsyn.latent_utils import get_input_train
import src

warnings.filterwarnings('ignore')


def get_class_labels_for_latent(dataname, data_dir):
    """
    Load target labels corresponding to the latent embeddings.
    
    Args:
        dataname: Name of the dataset
        data_dir: Path to data directory
    
    Returns:
        labels: numpy array of target labels
    """
    # Load info
    info_path = f'{data_dir}/info.json'
    with open(info_path, 'r') as f:
        info = json.load(f)
    
    task_type = info['task_type']
    
    if task_type not in ['binclass', 'multiclass']:
        return None
    
    # Load training labels
    _, _, y_train = src.read_pure_data(data_dir, 'train')
    
    if y_train is not None:
        # y_train is already in correct order matching train_z
        labels = y_train.flatten()
        return labels
    
    return None


def get_class_balanced_sampler(labels, minority_ratio=None):
    """
    Create a weighted sampler for class balancing in latent space.
    
    Args:
        labels: Target labels corresponding to latent embeddings
        minority_ratio: Desired ratio of minority class (e.g., 0.5 for 50:50)
                       If None, use balanced sampling (equal weights)
    
    Returns:
        WeightedRandomSampler
    """
    if labels is None:
        return None
    
    # Convert to numpy if tensor
    if isinstance(labels, torch.Tensor):
        labels = labels.numpy()
    
    # Count classes
    unique_classes, class_counts = np.unique(labels, return_counts=True)
    n_samples = len(labels)
    
    print(f"\nOriginal class distribution in latent space:")
    for cls, count in zip(unique_classes, class_counts):
        print(f"  Class {cls}: {count} ({count/n_samples*100:.2f}%)")
    
    # Calculate weights for each sample
    if minority_ratio is not None:
        # Custom ratio: minority_ratio for minority class, (1-minority_ratio) for majority
        # Assume binary classification: 0 = majority, 1 = minority
        target_ratios = {0: 1.0 - minority_ratio, 1: minority_ratio}
        
        # Calculate weight for each class
        class_weights = {}
        for cls in unique_classes:
            cls = int(cls)
            target_ratio = target_ratios.get(cls, 1.0 / len(unique_classes))
            current_ratio = class_counts[cls] / n_samples
            # Weight inversely proportional to current frequency, scaled to target ratio
            class_weights[cls] = target_ratio / current_ratio
        
        print(f"\nTarget ratio - Majority:Minority = {1-minority_ratio:.2f}:{minority_ratio:.2f}")
    else:
        # Balanced sampling: equal probability for all classes
        class_weights = {int(cls): n_samples / count for cls, count in zip(unique_classes, class_counts)}
        print(f"\nUsing balanced sampling (equal probability for all classes)")
    
    # Assign weight to each sample
    sample_weights = np.array([class_weights[int(label)] for label in labels])
    sample_weights = torch.from_numpy(sample_weights).double()
    
    print(f"Class weights: {class_weights}")
    
    # Create sampler
    sampler = WeightedRandomSampler(
        weights=sample_weights,
        num_samples=len(sample_weights),
        replacement=True
    )
    
    return sampler


def main(args): 
    device = args.device
    dataname = args.dataname
    data_dir = f'data/{dataname}'
    
    train_z, _, _, ckpt_path, _ = get_input_train(args)
    print(ckpt_path)
    
    if not os.path.exists(ckpt_path):
        os.makedirs(ckpt_path)
    
    in_dim = train_z.shape[1] 
    mean, std = train_z.mean(0), train_z.std(0)
    train_z = (train_z - mean) / 2
    
    # Convert to tensor
    train_z_tensor = torch.FloatTensor(train_z)
    
    batch_size = 4096
    
    # Load labels and create class-balanced sampler if needed
    if args.use_ratio:
        labels = get_class_labels_for_latent(dataname, data_dir)
        
        if labels is not None:
            sampler = get_class_balanced_sampler(labels, minority_ratio=args.minority_ratio)
            
            if sampler is not None:
                # Create TensorDataset with labels for tracking
                labels_tensor = torch.LongTensor(labels)
                train_dataset = TensorDataset(train_z_tensor, labels_tensor)
                
                train_loader = DataLoader(
                    train_dataset,
                    batch_size=batch_size,
                    sampler=sampler,  # Use weighted sampler
                    num_workers=4,
                )
                print("Using class-balanced sampler for diffusion training!")
            else:
                train_dataset = TensorDataset(train_z_tensor)
                train_loader = DataLoader(
                    train_dataset,
                    batch_size=batch_size,
                    shuffle=True,
                    num_workers=4,
                )
        else:
            print("Warning: Could not load labels, using regular sampling")
            train_dataset = TensorDataset(train_z_tensor)
            train_loader = DataLoader(
                train_dataset,
                batch_size=batch_size,
                shuffle=True,
                num_workers=4,
            )
    else:
        # Regular sampling without class balancing
        train_loader = DataLoader(
            train_z_tensor,
            batch_size=batch_size,
            shuffle=True,
            num_workers=4,
        )
    
    num_epochs = 10000 + 1
    denoise_fn = MLPDiffusion(in_dim, 1024).to(device)
    print(denoise_fn)
    
    num_params = sum(p.numel() for p in denoise_fn.parameters())
    print("the number of parameters", num_params)
    
    model = Model(denoise_fn=denoise_fn, hid_dim=train_z.shape[1]).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3, weight_decay=0)
    scheduler = ReduceLROnPlateau(optimizer, mode='min', factor=0.9, patience=20)
    
    model.train()
    best_loss = float('inf')
    patience = 0
    start_time = time.time()
    
    for epoch in range(num_epochs):
        pbar = tqdm(train_loader, total=len(train_loader))
        pbar.set_description(f"Epoch {epoch+1}/{num_epochs}")
        batch_loss = 0.0
        len_input = 0
        
        # Track class distribution in batches (for monitoring)
        epoch_class_counts = {}
        
        for batch_data in pbar:
            # Handle both cases: with and without labels
            if isinstance(batch_data, list) and len(batch_data) == 2:
                inputs, batch_labels = batch_data
                inputs = inputs.float().to(device)
                
                # Monitor class distribution in current batch
                if args.use_ratio and epoch % 100 == 0:
                    for label in batch_labels.numpy():
                        epoch_class_counts[int(label)] = epoch_class_counts.get(int(label), 0) + 1
            else:
                inputs = batch_data.float().to(device)
            
            loss = model(inputs)
            loss = loss.mean()
            
            batch_loss += loss.item() * len(inputs)
            len_input += len(inputs)
            
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            pbar.set_postfix({"Loss": loss.item()})
        
        curr_loss = batch_loss / len_input
        scheduler.step(curr_loss)
        
        # Print class distribution every 100 epochs
        if args.use_ratio and epoch % 100 == 0 and epoch_class_counts:
            print(f"\nEpoch {epoch} - Batch class distribution:")
            total_samples = sum(epoch_class_counts.values())
            for cls, count in sorted(epoch_class_counts.items()):
                print(f"  Class {cls}: {count} ({count/total_samples*100:.2f}%)")
        
        if curr_loss < best_loss:
            best_loss = curr_loss
            patience = 0
            torch.save(model.state_dict(), f'{ckpt_path}/model.pt')
        else:
            patience += 1
            if patience == 500:
                print('Early stopping')
                break
        
        if epoch % 1000 == 0:
            torch.save(model.state_dict(), f'{ckpt_path}/model_{epoch}.pt')
    
    end_time = time.time()
    print('Training time: {:.4f} mins'.format((end_time - start_time) / 60))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Training of TabSyn')
    
    parser.add_argument('--dataname', type=str, default='adult', help='Name of dataset.')
    parser.add_argument('--gpu', type=int, default=0, help='GPU index.')
    
    # Class balancing arguments
    parser.add_argument('--use_ratio', action='store_true', 
                        help='Use class balancing during diffusion training.')
    parser.add_argument('--minority_ratio', type=float, default=0.5, 
                        help='Desired ratio of minority class (e.g., 0.5 for 50:50 balance).')
    
    args = parser.parse_args()
    
    # check cuda
    if args.gpu != -1 and torch.cuda.is_available():
        args.device = f'cuda:{args.gpu}'
    else:
        args.device = 'cpu'
    
    main(args)