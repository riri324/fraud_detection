import numpy as np
import pandas as pd
import os
import sys
import json
import argparse
from sklearn.metrics import pairwise_distances
import warnings
warnings.filterwarnings("ignore")

def real_real_nn_baseline(real_df, feature_cols, class_col='Class', class_value=None, n_sample=2000, seed=42):
    """
    Real-Real NN baseline: 실제 데이터끼리의 최근접 이웃 거리 계산
    """
    if class_value is None:
        X = real_df[feature_cols].values
        tag = "ALL"
    else:
        X = real_df[real_df[class_col] == class_value][feature_cols].values
        tag = f"Class={class_value}"

    rng = np.random.default_rng(seed)
    n = min(n_sample, len(X))
    if n < 2:
        return {"group": tag, "RealReal_NN_mean": np.nan, "RealReal_NN_min": np.nan, "n_used": n}

    idx1 = rng.choice(len(X), n, replace=False)
    idx2 = rng.choice(len(X), n, replace=False)
    X1, X2 = X[idx1], X[idx2]

    d = pairwise_distances(X1, X2, metric="euclidean")
    # 자기 자신과의 거리(0)가 들어가면 최소가 0이 될 수 있으니 대각선 무시
    np.fill_diagonal(d, np.inf)

    min_d = d.min(axis=1)
    return {
        "group": tag, 
        "RealReal_NN_mean": float(min_d.mean()), 
        "RealReal_NN_min": float(min_d.min()), 
        "n_used": n
    }


def syn_real_nn_privacy(syn_df, real_df, feature_cols, class_col='Class', class_value=None, n_sample=2000, seed=42):
    """
    Synthetic-Real NN privacy: 합성 데이터와 실제 데이터 간의 최근접 이웃 거리 계산
    거리가 클수록 privacy가 높음
    """
    if class_value is None:
        X_syn = syn_df[feature_cols].values
        X_real = real_df[feature_cols].values
        tag = "ALL"
    else:
        X_syn = syn_df[syn_df[class_col] == class_value][feature_cols].values
        X_real = real_df[real_df[class_col] == class_value][feature_cols].values
        tag = f"Class={class_value}"

    rng = np.random.default_rng(seed)
    
    n_syn = min(n_sample, len(X_syn))
    n_real = min(n_sample, len(X_real))
    
    if n_syn < 1 or n_real < 1:
        return {
            "group": tag, 
            "SynReal_NN_mean": np.nan, 
            "SynReal_NN_min": np.nan, 
            "n_syn": n_syn, 
            "n_real": n_real
        }

    idx_syn = rng.choice(len(X_syn), n_syn, replace=False)
    idx_real = rng.choice(len(X_real), n_real, replace=False)
    
    X_syn_sample = X_syn[idx_syn]
    X_real_sample = X_real[idx_real]

    # 합성 데이터 각 샘플에서 실제 데이터까지의 거리 계산
    d = pairwise_distances(X_syn_sample, X_real_sample, metric="euclidean")
    
    min_d = d.min(axis=1)
    return {
        "group": tag,
        "SynReal_NN_mean": float(min_d.mean()),
        "SynReal_NN_min": float(min_d.min()),
        "n_syn": n_syn,
        "n_real": n_real
    }


def evaluate_privacy(train_syn, train_real, test_real, info, n_sample=2000, seed=42):
    """
    Privacy 평가 메트릭 계산
    """
    # info에서 필요한 정보 추출
    target_col = info.get('target', 'Class')
    
    # feature columns 추출 (target 제외)
    all_cols = list(train_syn.columns)
    if target_col in all_cols:
        feature_cols = [col for col in all_cols if col != target_col]
    else:
        feature_cols = all_cols
    
    results = {}
    
    # 1. Real-Real NN Baseline (전체)
    baseline_all = real_real_nn_baseline(
        train_real, feature_cols, 
        class_col=target_col,
        class_value=None, 
        n_sample=n_sample, 
        seed=seed
    )
    results['baseline_all'] = baseline_all
    
    # 2. Real-Real NN Baseline (각 클래스별)
    if target_col in train_real.columns:
        unique_classes = train_real[target_col].unique()
        for cls in unique_classes:
            baseline_cls = real_real_nn_baseline(
                train_real, feature_cols,
                class_col=target_col,
                class_value=cls,
                n_sample=n_sample,
                seed=seed
            )
            results[f'baseline_class_{cls}'] = baseline_cls
    
    # 3. Syn-Real NN Privacy (전체)
    privacy_all = syn_real_nn_privacy(
        train_syn, train_real, feature_cols,
        class_col=target_col,
        class_value=None,
        n_sample=n_sample,
        seed=seed
    )
    results['privacy_all'] = privacy_all
    
    # 4. Syn-Real NN Privacy (각 클래스별)
    if target_col in train_syn.columns and target_col in train_real.columns:
        unique_classes = train_syn[target_col].unique()
        for cls in unique_classes:
            privacy_cls = syn_real_nn_privacy(
                train_syn, train_real, feature_cols,
                class_col=target_col,
                class_value=cls,
                n_sample=n_sample,
                seed=seed
            )
            results[f'privacy_class_{cls}'] = privacy_cls
    
    return results


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataname', type=str, default='adult')
    parser.add_argument('--model', type=str, default='real')
    parser.add_argument('--path', type=str, default=None, help='The file path of the synthetic data')
    parser.add_argument('--n_sample', type=int, default=2000, help='Number of samples for NN calculation')
    parser.add_argument('--seed', type=int, default=42, help='Random seed')
    args = parser.parse_args()
    
    dataname = args.dataname
    model = args.model
    
    # 데이터 경로 설정
    if not args.path:
        train_syn_path = f'synthetic/{dataname}/{model}.csv'
    else:
        train_syn_path = args.path
    
    train_real_path = f'data/{dataname}/train.csv'
    test_real_path = f'synthetic/{dataname}/test.csv'
    info_path = f'data/{dataname}/info.json'
    
    # 데이터 로드
    print(f"Loading synthetic data from: {train_syn_path}")
    train_syn = pd.read_csv(train_syn_path)
    
    print(f"Loading real train data from: {train_real_path}")
    train_real = pd.read_csv(train_real_path)
    
    print(f"Loading test data from: {test_real_path}")
    test_real = pd.read_csv(test_real_path)
    
    print(f"Loading info from: {info_path}")
    with open(info_path, 'r') as f:
        info = json.load(f)
    
    # Privacy 평가
    print(f"\nEvaluating privacy metrics...")
    privacy_results = evaluate_privacy(
        train_syn, train_real, test_real, info,
        n_sample=args.n_sample,
        seed=args.seed
    )
    
    # 결과 저장
    save_dir = f'eval/privacy/{dataname}'
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    
    save_path = f'{save_dir}/{model}.json'
    print(f'\nSaving privacy scores to {save_path}')
    
    with open(save_path, "w") as json_file:
        json.dump(privacy_results, json_file, indent=4, separators=(", ", ": "))
    
    # 결과 요약 출력
    print("\n=== Privacy Evaluation Results ===")
    print(f"\nBaseline (Real-Real NN):")
    if 'baseline_all' in privacy_results:
        print(f"  All: mean={privacy_results['baseline_all']['RealReal_NN_mean']:.4f}, "
              f"min={privacy_results['baseline_all']['RealReal_NN_min']:.4f}")
    
    print(f"\nPrivacy (Syn-Real NN):")
    if 'privacy_all' in privacy_results:
        print(f"  All: mean={privacy_results['privacy_all']['SynReal_NN_mean']:.4f}, "
              f"min={privacy_results['privacy_all']['SynReal_NN_min']:.4f}")
    
    print("\nDone!")