#!/bin/bash

MODELS=("codi" "ctgan" "findiff" "real" "smote" "tabddpm" "tabsyn" "tvae")
# MODELS=("findiff" "real" "smote" "tvae")


for model in "${MODELS[@]}"
do
    echo "Running evaluation for model: $model"
    python eval/eval_mle.py --dataname fin1 --model "$model" --path "./synthetic/fin1/$model.csv" --hybrid
done
