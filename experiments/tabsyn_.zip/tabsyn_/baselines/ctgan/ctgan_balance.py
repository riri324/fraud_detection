from collections import Counter
from sklearn.datasets import make_classification
from sdv.single_table import CTGANSynthesizer
from sdv.metadata import SingleTableMetadata

import numpy as np
import pandas as pd
import src
import os
import json
import argparse
import warnings
import pickle

from tabsyn.latent_utils import recover_data
from utils_train import concat_y_to_X

warnings.filterwarnings("ignore")

def make_dataset(
    data_path: str,
    T: src.Transformations,
    task_type,
    change_val: bool,
    concat = True,
):

    # classification
    if task_type == 'binclass' or task_type == 'multiclass':
        X_cat = {} if os.path.exists(os.path.join(data_path, 'X_cat_train.npy'))  else None
        X_num = {} if os.path.exists(os.path.join(data_path, 'X_num_train.npy')) else None
        y = {} if os.path.exists(os.path.join(data_path, 'y_train.npy')) else None

        for split in ['train', 'test']:
            X_num_t, X_cat_t, y_t = src.read_pure_data(data_path, split)
            if X_num is not None:
                X_num[split] = X_num_t
            if X_cat is not None:
                if concat:
                    X_cat_t = concat_y_to_X(X_cat_t, y_t)
                X_cat[split] = X_cat_t  
            if y is not None:
                y[split] = y_t
    else:
        # regression
        X_cat = {} if os.path.exists(os.path.join(data_path, 'X_cat_train.npy')) else None
        X_num = {} if os.path.exists(os.path.join(data_path, 'X_num_train.npy')) else None
        y = {} if os.path.exists(os.path.join(data_path, 'y_train.npy')) else None

        for split in ['train', 'test']:
            X_num_t, X_cat_t, y_t = src.read_pure_data(data_path, split)

            if X_num is not None:
                if concat:
                    X_num_t = concat_y_to_X(X_num_t, y_t)
                X_num[split] = X_num_t
            if X_cat is not None:
                X_cat[split] = X_cat_t
            if y is not None:
                y[split] = y_t

    info = src.load_json(os.path.join(data_path, 'info.json'))
    

    D = src.Dataset(
        X_num,
        X_cat,
        y,
        y_info={},
        task_type=src.TaskType(info['task_type']),
        n_classes=info.get('n_classes')
    )
    

    if change_val:
        D = src.change_val(D)

    D =  src.transform_dataset(D, T, None)
    
    return D


class ImbalancedCTGANSynthesizer(CTGANSynthesizer):
    def __init__(self, metadata, epochs=300, verbose=True, sampling_strategy='ratio', target_ratio=None):
        super().__init__(metadata=metadata, epochs=epochs, verbose=verbose)
        self.sampling_strategy = sampling_strategy
        self.target_ratio = target_ratio
        self.target_column = None
        
    def fit(self, data):
        if self.sampling_strategy == 'oversample' and self.target_ratio is not None:
            data = self._oversample_data(data)
        
        super().fit(data)
        
    def _oversample_data(self, data):
        if self.target_column is None:
            raise ValueError("Target column must be set for oversampling")
        
        class_counts = data[self.target_column].value_counts()
        max_class = class_counts.idxmax()
        max_count = class_counts.max()
        
        oversampled_dfs = []
        for class_label in class_counts.index:
            class_data = data[data[self.target_column] == class_label]
            current_count = len(class_data)
            
            if self.target_ratio is not None:
                target_count = int(max_count * self.target_ratio.get(class_label, 1.0))
            else:
                target_count = max_count
            
            if current_count < target_count:
                n_samples = target_count - current_count
                oversampled = class_data.sample(n=n_samples, replace=True, random_state=42)
                oversampled_dfs.append(class_data)
                oversampled_dfs.append(oversampled)
            else:
                oversampled_dfs.append(class_data)
        
        return pd.concat(oversampled_dfs, axis=0).reset_index(drop=True)


def main(args):
    dataname = args.dataname
    dataset_path = f'data/{dataname}'

    with open(f'{dataset_path}/info.json', 'r') as f:
        info = json.load(f)

    task_type = info['task_type']
    
    X_num_train, X_cat_train, y_train = src.read_pure_data(dataset_path, 'train')
    
    train_data = []
    
    num_col_idx = info['num_col_idx']
    cat_col_idx = info['cat_col_idx']
    target_col_idx = info['target_col_idx']
    
    idx_name_mapping = info['idx_name_mapping']
    idx_name_mapping = {int(key): value for key, value in idx_name_mapping.items()}
    
    if X_num_train is not None and X_cat_train is not None:
        all_data = np.concatenate([X_num_train, X_cat_train, y_train], axis=1)
    elif X_num_train is not None:
        all_data = np.concatenate([X_num_train, y_train], axis=1)
    else:
        all_data = np.concatenate([X_cat_train, y_train], axis=1)
    
    train_df = pd.DataFrame(all_data)
    train_df.rename(columns=idx_name_mapping, inplace=True)
    train_df.columns = [info['column_names'][i] for i in info['num_col_idx'] + info['cat_col_idx']] + [info['column_names'][info['target_col_idx'][0]]]
    
    for idx in num_col_idx:
        col_name = idx_name_mapping[idx]
        train_df[col_name] = pd.to_numeric(train_df[col_name], errors='coerce')
    
    for idx in cat_col_idx:
        col_name = idx_name_mapping[idx]
        train_df[col_name] = pd.to_numeric(train_df[col_name], errors='coerce').astype('Int64')
    
    if isinstance(target_col_idx, list):
        target_col_idx = target_col_idx[0]
    target_col_name = idx_name_mapping[target_col_idx]
    if task_type in ['binclass', 'multiclass']:
        train_df[target_col_name] = pd.to_numeric(train_df[target_col_name], errors='coerce').astype('Int64')
    else:
        train_df[target_col_name] = pd.to_numeric(train_df[target_col_name], errors='coerce')
    
    print(f"Original class distribution:\n{train_df[target_col_name].value_counts()}")
    
    metadata = SingleTableMetadata()
    metadata.detect_from_dataframe(train_df)
    
    if args.mode == 'oversample':
        target_ratio = None
        if args.target_ratio:
            target_ratio = {}
            ratio_list = args.target_ratio.split(',')
            unique_classes = sorted(train_df[target_col_name].unique())
            for i, ratio_str in enumerate(ratio_list):
                if i < len(unique_classes):
                    target_ratio[unique_classes[i]] = float(ratio_str)
        
        ctgan = ImbalancedCTGANSynthesizer(
            metadata=metadata,
            epochs=args.epochs,
            verbose=True,
            sampling_strategy='oversample',
            target_ratio=target_ratio
        )
        ctgan.target_column = target_col_name
        
        print(f"Training CTGAN with oversampling (target_ratio: {target_ratio})...")
        ctgan.fit(train_df)
        
    elif args.mode == 'dynamic':
        print(f"Training CTGAN with dynamic sampling...")
        
        ctgan = CTGANSynthesizer(
            metadata=metadata,
            epochs=args.epochs,
            verbose=True
        )
        
        if args.target_ratio:
            ratio_list = args.target_ratio.split(',')
            unique_classes = sorted(train_df[target_col_name].unique())
            target_ratio = {}
            for i, ratio_str in enumerate(ratio_list):
                if i < len(unique_classes):
                    target_ratio[unique_classes[i]] = float(ratio_str)
            
            class_counts = train_df[target_col_name].value_counts()
            total_count = len(train_df)
            
            sampled_dfs = []
            for class_label in unique_classes:
                class_data = train_df[train_df[target_col_name] == class_label]
                target_count = int(total_count * target_ratio.get(class_label, class_counts[class_label] / total_count))
                sampled = class_data.sample(n=min(target_count, len(class_data)), replace=True, random_state=42)
                sampled_dfs.append(sampled)
            
            train_df = pd.concat(sampled_dfs, axis=0).reset_index(drop=True)
            print(f"Sampled class distribution:\n{train_df[target_col_name].value_counts()}")
        
        ctgan.fit(train_df)
    else:
        print(f"Training CTGAN (standard mode)...")
        ctgan = CTGANSynthesizer(
            metadata=metadata,
            epochs=args.epochs,
            verbose=True
        )
        ctgan.fit(train_df)
    
    model_save_dir = os.path.join(os.path.dirname(__file__), dataname)
    os.makedirs(model_save_dir, exist_ok=True)
    model_save_path = os.path.join(model_save_dir, f'ctgan_model_{args.mode}.pkl')
    
    with open(model_save_path, 'wb') as f:
        pickle.dump(ctgan, f)
    print(f"Model saved to {model_save_path}")
    
    num_samples = len(train_df)
    print(f"Generating {num_samples} synthetic samples...")
    syn_df = ctgan.sample(num_samples)
    
    syn_df.columns = [info['column_names'][i] for i in info['num_col_idx'] + info['cat_col_idx']] + [info['column_names'][info['target_col_idx'][0]]]
    syn_df = syn_df[info['column_names']]
    
    save_path = f'synthetic/{dataname}/ctgan_{args.mode}.csv'
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    syn_df.to_csv(save_path, index=False)
    
    print(f'Saving sampled data to {save_path}')
    print(f"Synthetic data shape: {syn_df.shape}")
    print(f"Synthetic class distribution:\n{syn_df[target_col_name].value_counts()}")

    
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='CTGAN')

    parser.add_argument('--dataname', type=str, default='adult', help='Name of dataset.')
    parser.add_argument('--epochs', type=int, default=300, help='Number of training epochs for CTGAN.')
    parser.add_argument('--mode', type=str, default='standard', choices=['standard', 'oversample', 'dynamic'], 
                        help='Training mode: standard, oversample, or dynamic')
    parser.add_argument('--target_ratio', type=str, default=None, 
                        help='Target ratio for each class (comma-separated, e.g., "0.5,0.5" for 50:50)')
    args = parser.parse_args()

    main(args)