from collections import Counter
from sklearn.datasets import make_classification
from sdv.single_table import CTGANSynthesizer
from sdv.metadata import SingleTableMetadata

import numpy as np
import pandas as pd
import src
import os
import json
import argparse
import warnings

from tabsyn.latent_utils import recover_data
from utils_train import concat_y_to_X

warnings.filterwarnings("ignore")

def make_dataset(
    data_path: str,
    T: src.Transformations,
    task_type,
    change_val: bool,
    concat = True,
):

    # classification
    if task_type == 'binclass' or task_type == 'multiclass':
        X_cat = {} if os.path.exists(os.path.join(data_path, 'X_cat_train.npy'))  else None
        X_num = {} if os.path.exists(os.path.join(data_path, 'X_num_train.npy')) else None
        y = {} if os.path.exists(os.path.join(data_path, 'y_train.npy')) else None

        for split in ['train', 'test']:
            X_num_t, X_cat_t, y_t = src.read_pure_data(data_path, split)
            if X_num is not None:
                X_num[split] = X_num_t
            if X_cat is not None:
                if concat:
                    X_cat_t = concat_y_to_X(X_cat_t, y_t)
                X_cat[split] = X_cat_t  
            if y is not None:
                y[split] = y_t
    else:
        # regression
        X_cat = {} if os.path.exists(os.path.join(data_path, 'X_cat_train.npy')) else None
        X_num = {} if os.path.exists(os.path.join(data_path, 'X_num_train.npy')) else None
        y = {} if os.path.exists(os.path.join(data_path, 'y_train.npy')) else None

        for split in ['train', 'test']:
            X_num_t, X_cat_t, y_t = src.read_pure_data(data_path, split)

            if X_num is not None:
                if concat:
                    X_num_t = concat_y_to_X(X_num_t, y_t)
                X_num[split] = X_num_t
            if X_cat is not None:
                X_cat[split] = X_cat_t
            if y is not None:
                y[split] = y_t

    info = src.load_json(os.path.join(data_path, 'info.json'))
    

    D = src.Dataset(
        X_num,
        X_cat,
        y,
        y_info={},
        task_type=src.TaskType(info['task_type']),
        n_classes=info.get('n_classes')
    )
    

    if change_val:
        D = src.change_val(D)

    D =  src.transform_dataset(D, T, None)
    
    return D

def main(args):
    dataname = args.dataname
    dataset_path = f'data/{dataname}'

    with open(f'{dataset_path}/info.json', 'r') as f:
        info = json.load(f)

    task_type = info['task_type']
    
    # Load original data for CTGAN
    X_num_train, X_cat_train, y_train = src.read_pure_data(dataset_path, 'train')
    
    # Prepare training data
    train_data = []
    
    num_col_idx = info['num_col_idx']
    cat_col_idx = info['cat_col_idx']
    target_col_idx = info['target_col_idx']
    
    idx_name_mapping = info['idx_name_mapping']
    idx_name_mapping = {int(key): value for key, value in idx_name_mapping.items()}
    
    # Combine all data into DataFrame
    if X_num_train is not None and X_cat_train is not None:
        # For mixed data
        all_data = np.concatenate([X_num_train, X_cat_train, y_train], axis=1)
    elif X_num_train is not None:
        # Only numerical
        all_data = np.concatenate([X_num_train, y_train], axis=1)
    else:
        # Only categorical
        all_data = np.concatenate([X_cat_train, y_train], axis=1)
    
    train_df = pd.DataFrame(all_data)
    train_df.rename(columns=idx_name_mapping, inplace=True)
    train_df.columns = [info['column_names'][i] for i in info['num_col_idx'] + info['cat_col_idx']] + [info['column_names'][info['target_col_idx'][0]]]
    # Convert data types properly
    # Numerical columns
    for idx in num_col_idx:
        col_name = idx_name_mapping[idx]
        train_df[col_name] = pd.to_numeric(train_df[col_name], errors='coerce')
    
    # Categorical columns - convert to int or keep as category
    for idx in cat_col_idx:
        col_name = idx_name_mapping[idx]
        train_df[col_name] = pd.to_numeric(train_df[col_name], errors='coerce').astype('Int64')
    
    # Target column (target_col_idx might be a list)
    if isinstance(target_col_idx, list):
        target_col_idx = target_col_idx[0]
    target_col_name = idx_name_mapping[target_col_idx]
    if task_type in ['binclass', 'multiclass']:
        train_df[target_col_name] = pd.to_numeric(train_df[target_col_name], errors='coerce').astype('Int64')
    else:
        train_df[target_col_name] = pd.to_numeric(train_df[target_col_name], errors='coerce')
    
    print(f"Training CTGAN on {len(train_df)} samples...")
    print(f"Data types:\n{train_df.dtypes}")
    
    # Create metadata
    metadata = SingleTableMetadata()
    metadata.detect_from_dataframe(train_df)
    
    # Initialize and train CTGAN with new API
    ctgan = CTGANSynthesizer(
        metadata=metadata,
        epochs=args.epochs,
        verbose=True
    )
    ctgan.fit(train_df)
    
    # Generate synthetic samples
    num_samples = len(train_df)
    print(f"Generating {num_samples} synthetic samples...")
    syn_df = ctgan.sample(num_samples)
    
    syn_df.columns = [info['column_names'][i] for i in info['num_col_idx'] + info['cat_col_idx']] + [info['column_names'][info['target_col_idx'][0]]]
    syn_df = syn_df[info['column_names']]
    
    # Save synthetic data
    save_path = f'synthetic/{dataname}/ctgan.csv'
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    syn_df.to_csv(save_path, index=False)
    
    print('Saving sampled data to {}'.format(save_path))
    print(f"Synthetic data shape: {syn_df.shape}")

    
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='CTGAN')

    parser.add_argument('--dataname', type=str, default='adult', help='Name of dataset.')
    parser.add_argument('--epochs', type=int, default=300, help='Number of training epochs for CTGAN.')
    args = parser.parse_args()

    main(args)