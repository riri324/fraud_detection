from collections import Counter
import numpy as np
import pandas as pd
import src
import os
import json
import argparse
import warnings
import math

from tabsyn.latent_utils import recover_data
from utils_train import concat_y_to_X

from sklearn.preprocessing import LabelEncoder, QuantileTransformer

import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset
import torch.optim as optim
from torch.optim.lr_scheduler import CosineAnnealingLR

from tqdm import tqdm
from datetime import datetime

warnings.filterwarnings("ignore")

# FinDiff Model Classes
class BaseNetwork(nn.Module):
    def __init__(self, hidden_size, activation='lrelu'):
        super(BaseNetwork, self).__init__()
        self.layers = self.init_layers(hidden_size)

        if activation == 'lrelu':
            self.activation = nn.LeakyReLU(negative_slope=0.4, inplace=True)
        elif activation == 'relu':
            self.activation = nn.ReLU(inplace=True)
        elif activation == 'tanh':
            self.activation = nn.Tanh()
        else:
            self.activation = nn.Sigmoid()

    def init_layers(self, layer_dimensions):
        layers = []
        for i in range(len(layer_dimensions)-1):
            layer = nn.Linear(layer_dimensions[i], layer_dimensions[i + 1], bias=True)
            nn.init.xavier_uniform_(layer.weight)
            nn.init.constant_(layer.bias, 0.0)
            layers.append(layer)
            self.add_module('linear_' + str(i), layer)
        return layers

    def forward(self, x):
        for i in range(len(self.layers)):
            x = self.activation(self.layers[i](x))
        return x


class MLPSynthesizer(nn.Module):
    def __init__(
            self, 
            d_in: int, 
            hidden_layers: list, 
            activation: str='lrelu',
            dim_t: int=64, 
            n_cat_tokens=None,
            n_cat_emb=None,
            embedding=None, 
            embedding_learned=True, 
            n_classes=None
        ):
        super(MLPSynthesizer, self).__init__()
        self.dim_t = dim_t
        self.backbone = BaseNetwork([dim_t, *hidden_layers], activation=activation)
        
        if embedding is not None:
            self.cat_embedding = nn.Embedding.from_pretrained(embeddings=embedding)
        else:
            self.cat_embedding = nn.Embedding(n_cat_tokens, n_cat_emb, max_norm=None, scale_grad_by_freq=False)
            self.cat_embedding.weight.requires_grad = embedding_learned

        if n_classes is not None:
            self.label_embedding = nn.Embedding(n_classes, dim_t)

        self.projection = nn.Sequential(
            nn.Linear(d_in, dim_t),
            nn.SiLU(),
            nn.Linear(dim_t, dim_t)
        )
        
        self.time_embed = nn.Sequential(
            nn.Linear(dim_t, dim_t),
            nn.SiLU(),
            nn.Linear(dim_t, dim_t)
        )
        
        self.head = nn.Linear(hidden_layers[-1], d_in)

    def embed_time(self, timesteps, dim_out, max_period=10000):
        half_dim_out = dim_out // 2
        freqs = torch.exp(-math.log(max_period) * torch.arange(start=0, end=half_dim_out, dtype=torch.float32) / half_dim_out)
        freqs = freqs.to(device=timesteps.device)
        args = timesteps[:, None].float() * freqs[None]
        time_embedding = torch.cat([torch.cos(args), torch.sin(args)], dim=-1)
        if dim_out % 2:
            time_embedding = torch.cat([time_embedding, torch.zeros_like(time_embedding[:, :1])], dim=-1)
        return time_embedding

    def get_embeddings(self):
        return self.cat_embedding.weight.data

    def embed_categorical(self, x_cat):
        x_cat_emb = self.cat_embedding(x_cat)
        x_cat_emb = x_cat_emb.view(-1, x_cat_emb.shape[1] * x_cat_emb.shape[2])
        return x_cat_emb

    def forward(self, x, timesteps, label=None):
        time_emb = self.embed_time(timesteps, self.dim_t)
        time_emb = self.time_embed(time_emb)
        
        if label is not None:
            time_label_emb = time_emb + self.label_embedding(label)

        x = self.projection(x)
        x = x + time_label_emb
        x = self.backbone(x)
        x = self.head(x)
        return x


class BaseDiffuser(object):
    def __init__(
            self, 
            total_steps=1000, 
            beta_start=1e-4, 
            beta_end=0.02, 
            device='cpu',
            scheduler='linear'
        ):
        self.total_steps = total_steps
        self.beta_start = beta_start
        self.beta_end = beta_end
        self.device = device
        self.alphas, self.betas = self.prepare_noise_schedule(scheduler=scheduler)
        self.alphas_hat = torch.cumprod(self.alphas, dim=0)

    def prepare_noise_schedule(self, scheduler: str):
        scale = 1000 / self.total_steps
        beta_start = scale * self.beta_start
        beta_end = scale * self.beta_end

        if scheduler == 'linear':
            betas = torch.linspace(beta_start, beta_end, self.total_steps)
            alphas = 1.0 - betas
        elif scheduler == 'quad':
            betas = torch.linspace(self.beta_start ** 0.5, self.beta_end ** 0.5, self.total_steps) ** 2
            alphas = 1.0 - betas

        return alphas.to(self.device), betas.to(self.device)

    def sample_random_timesteps(self, n: int):
        t = torch.randint(low=1, high=self.total_steps, size=(n,), device=self.device)
        return t

    def add_gauss_noise(self, x_num, t):
        sqrt_alpha_hat = torch.sqrt(self.alphas_hat[t])[:, None]
        sqrt_one_minus_alpha_hat = torch.sqrt(1 - self.alphas_hat[t])[:, None]
        noise_num = torch.randn_like(x_num)
        x_noise_num = sqrt_alpha_hat * x_num + sqrt_one_minus_alpha_hat * noise_num
        return x_noise_num, noise_num

    def p_sample_gauss(self, model_out, z_norm, timesteps):
        sqrt_alpha_t = torch.sqrt(self.alphas[timesteps])[:, None]
        betas_t = self.betas[timesteps][:, None]
        sqrt_one_minus_alpha_hat_t = torch.sqrt(1 - self.alphas_hat[timesteps])[:, None]
        epsilon_t = torch.sqrt(self.betas[timesteps][:, None])

        random_noise = torch.randn_like(z_norm)
        random_noise[timesteps == 0] = 0.0

        model_mean = ((1 / sqrt_alpha_t) * (z_norm - (betas_t * model_out / sqrt_one_minus_alpha_hat_t)))
        z_norm = model_mean + (epsilon_t * random_noise)
        return z_norm


def make_dataset(
    data_path: str,
    T: src.Transformations,
    task_type,
    change_val: bool,
    concat = True,
):
    if task_type == 'binclass' or task_type == 'multiclass':
        X_cat = {} if os.path.exists(os.path.join(data_path, 'X_cat_train.npy')) else None
        X_num = {} if os.path.exists(os.path.join(data_path, 'X_num_train.npy')) else None
        y = {} if os.path.exists(os.path.join(data_path, 'y_train.npy')) else None

        for split in ['train', 'test']:
            X_num_t, X_cat_t, y_t = src.read_pure_data(data_path, split)
            if X_num is not None:
                X_num[split] = X_num_t
            if X_cat is not None:
                if concat:
                    X_cat_t = concat_y_to_X(X_cat_t, y_t)
                X_cat[split] = X_cat_t  
            if y is not None:
                y[split] = y_t
    else:
        X_cat = {} if os.path.exists(os.path.join(data_path, 'X_cat_train.npy')) else None
        X_num = {} if os.path.exists(os.path.join(data_path, 'X_num_train.npy')) else None
        y = {} if os.path.exists(os.path.join(data_path, 'y_train.npy')) else None

        for split in ['train', 'test']:
            X_num_t, X_cat_t, y_t = src.read_pure_data(data_path, split)
            if X_num is not None:
                if concat:
                    X_num_t = concat_y_to_X(X_num_t, y_t)
                X_num[split] = X_num_t
            if X_cat is not None:
                X_cat[split] = X_cat_t
            if y is not None:
                y[split] = y_t

    info = src.load_json(os.path.join(data_path, 'info.json'))
    
    D = src.Dataset(
        X_num,
        X_cat,
        y,
        y_info={},
        task_type=src.TaskType(info['task_type']),
        n_classes=info.get('n_classes')
    )
    
    if change_val:
        D = src.change_val(D)

    D = src.transform_dataset(D, T, None)
    
    return D


def main(args):
    dataname = args.dataname
    dataset_path = f'data/{dataname}'

    with open(f'{dataset_path}/info.json', 'r') as f:
        info = json.load(f)

    task_type = info['task_type']
    
    # Set random seeds
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed(args.seed)
    
    # Set device
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    
    # Load original data
    X_num_train, X_cat_train, y_train = src.read_pure_data(dataset_path, 'train')
    
    # Determine attributes
    num_col_idx = info['num_col_idx']
    cat_col_idx = info['cat_col_idx']
    target_col_idx = info['target_col_idx']
    
    num_attrs = [f'num_{i}' for i in range(len(num_col_idx))]
    cat_attrs = [f'cat_{i}' for i in range(len(cat_col_idx))]
    
    # Prepare DataFrame
    train_data = {}
    if X_num_train is not None:
        for i, col in enumerate(num_attrs):
            train_data[col] = X_num_train[:, i]
    if X_cat_train is not None:
        for i, col in enumerate(cat_attrs):
            train_data[col] = X_cat_train[:, i].astype(str).astype(object)
            # Add prefix to categorical values
            train_data[col] = col + '_' + train_data[col]
    
    train = pd.DataFrame(train_data)
    label = y_train.squeeze()
    
    # Transform numerical attributes
    if len(num_attrs) > 0:
        num_scaler = QuantileTransformer(output_distribution='normal', random_state=args.seed)
        num_scaler.fit(train[num_attrs])
        train_num_scaled = num_scaler.transform(train[num_attrs])
    else:
        train_num_scaled = np.array([]).reshape(len(train), 0)
    
    # Transform categorical attributes
    if len(cat_attrs) > 0:
        vocabulary_classes = np.unique(train[cat_attrs])
        label_encoder = LabelEncoder()
        label_encoder.fit(vocabulary_classes)
        train_cat_scaled = train[cat_attrs].apply(label_encoder.transform)
        vocab_per_attr = {cat_attr: set(train_cat_scaled[cat_attr]) for cat_attr in cat_attrs}
    else:
        train_cat_scaled = pd.DataFrame()
        vocab_per_attr = {}
    
    # Convert to tensors
    train_num_torch = torch.FloatTensor(train_num_scaled)
    train_cat_torch = torch.LongTensor(train_cat_scaled.values) if len(cat_attrs) > 0 else torch.empty((train_num_torch.size(0), 0))
    label_torch = torch.LongTensor(label)
    
    # Create dataset
    train_set = TensorDataset(train_cat_torch, train_num_torch, label_torch)
    dataloader = DataLoader(dataset=train_set, batch_size=args.batch_size, num_workers=0, shuffle=True)
    
    # Determine dimensions
    n_cat_tokens = len(np.unique(train[cat_attrs])) if len(cat_attrs) > 0 else 0
    cat_dim = args.cat_emb_dim * len(cat_attrs)
    num_dim = len(num_attrs)
    encoded_dim = cat_dim + num_dim
    
    # Initialize models
    synthesizer_model = MLPSynthesizer(
        d_in=encoded_dim,
        hidden_layers=args.mlp_layers,
        activation='lrelu',
        n_cat_tokens=n_cat_tokens if n_cat_tokens > 0 else 1,
        n_cat_emb=args.cat_emb_dim,
        n_classes=pd.Series(label).nunique(),
        embedding_learned=False
    )
    
    diffuser_model = BaseDiffuser(
        total_steps=args.diffusion_steps,
        beta_start=args.diffusion_beta_start,
        beta_end=args.diffusion_beta_end,
        scheduler=args.scheduler,
        device=device
    )
    
    # Initialize optimizer
    parameters = filter(lambda p: p.requires_grad, synthesizer_model.parameters())
    optimizer = optim.Adam(parameters, lr=args.learning_rate)
    lr_scheduler = CosineAnnealingLR(optimizer, T_max=args.epochs)
    loss_fnc = nn.MSELoss()
    
    # Training
    print(f"Training FinDiff on {len(train)} samples...")
    synthesizer_model.train()
    synthesizer_model = synthesizer_model.to(device)
    
    pbar = tqdm(iterable=range(args.epochs), position=0, leave=True)
    for epoch in pbar:
        batch_losses = []
        for batch_cat, batch_num, batch_y in dataloader:
            batch_cat = batch_cat.to(device)
            batch_num = batch_num.to(device)
            batch_y = batch_y.to(device)
            
            timesteps = diffuser_model.sample_random_timesteps(n=batch_cat.shape[0])
            
            if len(cat_attrs) > 0:
                batch_cat_emb = synthesizer_model.embed_categorical(x_cat=batch_cat)
                batch_cat_num = torch.cat((batch_cat_emb, batch_num), dim=1)
            else:
                batch_cat_num = batch_num
            
            batch_noise_t, noise_t = diffuser_model.add_gauss_noise(x_num=batch_cat_num, t=timesteps)
            predicted_noise = synthesizer_model(x=batch_noise_t, timesteps=timesteps, label=batch_y)
            
            batch_loss = loss_fnc(input=noise_t, target=predicted_noise)
            optimizer.zero_grad()
            batch_loss.backward()
            optimizer.step()
            
            batch_losses.append(batch_loss.detach().cpu().numpy())
        
        batch_losses_mean = np.mean(np.array(batch_losses))
        lr_scheduler.step()
        
        now = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
        pbar.set_description('[LOG {}] epoch: {}, train-loss: {:.6f}'.format(str(now), str(epoch).zfill(4), batch_losses_mean))
    
    # Generation
    print(f"Generating {len(label_torch)} synthetic samples...")
    synthesizer_model.eval()
    
    samples = torch.randn((len(label_torch), encoded_dim), device=device)
    pbar = tqdm(iterable=reversed(range(0, args.diffusion_steps)), position=0, leave=True)
    
    with torch.no_grad():
        for diffusion_step in pbar:
            now = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
            pbar.set_description('[LOG {}] Diffusion Step: {}'.format(str(now), str(diffusion_step).zfill(4)))
            
            timesteps = torch.full((len(label_torch),), diffusion_step, dtype=torch.long, device=device)
            model_out = synthesizer_model(x=samples.float(), timesteps=timesteps, label=label_torch.to(device))
            samples = diffuser_model.p_sample_gauss(model_out, samples, timesteps)
    
    # Decode samples
    samples = samples.detach().cpu().numpy()
    samples_num = samples[:, cat_dim:]
    samples_cat = samples[:, :cat_dim]
    
    # Denormalize numerical attributes
    if len(num_attrs) > 0:
        z_norm_upscaled = num_scaler.inverse_transform(samples_num)
        z_norm_df = pd.DataFrame(z_norm_upscaled, columns=num_attrs)
    else:
        z_norm_df = pd.DataFrame()
    
    # Decode categorical attributes
    if len(cat_attrs) > 0:
        embedding_lookup = synthesizer_model.get_embeddings().cpu()
        samples_cat = samples_cat.reshape(-1, len(cat_attrs), args.cat_emb_dim)
        distances = torch.cdist(x1=embedding_lookup, x2=torch.Tensor(samples_cat))
        
        z_cat_df = pd.DataFrame(index=range(len(samples_cat)), columns=cat_attrs)
        
        for attr_idx, attr_name in enumerate(cat_attrs):
            attr_emb_idx = list(vocab_per_attr[attr_name])
            attr_distances = distances[:, attr_emb_idx, attr_idx]
            nearest_values, nearest_idx = torch.min(attr_distances, dim=1)
            nearest_idx = nearest_idx.cpu().numpy()
            z_cat_df[attr_name] = np.array(attr_emb_idx)[nearest_idx]
        
        z_cat_df = z_cat_df.apply(label_encoder.inverse_transform)
        
        # Remove prefix from categorical values
        for col in cat_attrs:
            z_cat_df[col] = z_cat_df[col].str.replace(f'{col}_', '')
    else:
        z_cat_df = pd.DataFrame()
    
    samples_decoded = pd.concat([z_cat_df, z_norm_df], axis=1)
    
    # Reconstruct original format
    idx_name_mapping = info['idx_name_mapping']
    idx_name_mapping = {int(key): value for key, value in idx_name_mapping.items()}
    
    # Prepare final output
    final_data = {}
    
    if X_num_train is not None:
        for i, orig_idx in enumerate(num_col_idx):
            col_name = num_attrs[i]
            final_data[idx_name_mapping[orig_idx]] = samples_decoded[col_name].values
    
    if X_cat_train is not None:
        for i, orig_idx in enumerate(cat_col_idx):
            col_name = cat_attrs[i]
            final_data[idx_name_mapping[orig_idx]] = samples_decoded[col_name].values
    
    # Add target
    for i, orig_idx in enumerate(target_col_idx):
        final_data[idx_name_mapping[orig_idx]] = label
    
    syn_df = pd.DataFrame(final_data)
    
    syn_df = syn_df[info['column_names']]
    
    # Save
    save_path = f'synthetic/{dataname}/findiff.csv'
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    syn_df.to_csv(save_path, index=False)
    
    print('Saving sampled data to {}'.format(save_path))
    print(f"Synthetic data shape: {syn_df.shape}")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='FinDiff')

    parser.add_argument('--dataname', type=str, default='adult', help='Name of dataset.')
    parser.add_argument('--seed', type=int, default=1234, help='Random seed.')
    parser.add_argument('--cat_emb_dim', type=int, default=2, help='Categorical embedding dimension.')
    parser.add_argument('--mlp_layers', type=int, nargs='+', default=[1024, 1024, 1024, 1024], help='MLP layer sizes.')
    parser.add_argument('--activation', type=str, default='lrelu', help='Activation function.')
    parser.add_argument('--diffusion_steps', type=int, default=500, help='Number of diffusion steps.')
    parser.add_argument('--diffusion_beta_start', type=float, default=1e-4, help='Diffusion beta start.')
    parser.add_argument('--diffusion_beta_end', type=float, default=0.02, help='Diffusion beta end.')
    parser.add_argument('--scheduler', type=str, default='linear', help='Diffusion scheduler.')
    parser.add_argument('--epochs', type=int, default=500, help='Number of training epochs.')
    parser.add_argument('--batch_size', type=int, default=512, help='Training batch size.')
    parser.add_argument('--learning_rate', type=float, default=1e-4, help='Learning rate.')
    
    args = parser.parse_args()

    main(args)