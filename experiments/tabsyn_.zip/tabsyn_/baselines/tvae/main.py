from collections import Counter
from sklearn.datasets import make_classification
from sdv.single_table import TVAESynthesizer
from sdv.metadata import SingleTableMetadata
from sdv.sampling import Condition

import numpy as np
import pandas as pd
import src
import os
import json
import argparse
import warnings

from tabsyn.latent_utils import recover_data
from utils_train import concat_y_to_X

warnings.filterwarnings("ignore")

def make_dataset(
    data_path: str,
    T: src.Transformations,
    task_type,
    change_val: bool,
    concat = True,
):

    # classification
    if task_type == 'binclass' or task_type == 'multiclass':
        X_cat = {} if os.path.exists(os.path.join(data_path, 'X_cat_train.npy'))  else None
        X_num = {} if os.path.exists(os.path.join(data_path, 'X_num_train.npy')) else None
        y = {} if os.path.exists(os.path.join(data_path, 'y_train.npy')) else None

        for split in ['train', 'test']:
            X_num_t, X_cat_t, y_t = src.read_pure_data(data_path, split)
            if X_num is not None:
                X_num[split] = X_num_t
            if X_cat is not None:
                if concat:
                    X_cat_t = concat_y_to_X(X_cat_t, y_t)
                X_cat[split] = X_cat_t  
            if y is not None:
                y[split] = y_t
    else:
        # regression
        X_cat = {} if os.path.exists(os.path.join(data_path, 'X_cat_train.npy')) else None
        X_num = {} if os.path.exists(os.path.join(data_path, 'X_num_train.npy')) else None
        y = {} if os.path.exists(os.path.join(data_path, 'y_train.npy')) else None

        for split in ['train', 'test']:
            X_num_t, X_cat_t, y_t = src.read_pure_data(data_path, split)

            if X_num is not None:
                if concat:
                    X_num_t = concat_y_to_X(X_num_t, y_t)
                X_num[split] = X_num_t
            if X_cat is not None:
                X_cat[split] = X_cat_t
            if y is not None:
                y[split] = y_t

    info = src.load_json(os.path.join(data_path, 'info.json'))
    

    D = src.Dataset(
        X_num,
        X_cat,
        y,
        y_info={},
        task_type=src.TaskType(info['task_type']),
        n_classes=info.get('n_classes')
    )
    

    if change_val:
        D = src.change_val(D)

    D =  src.transform_dataset(D, T, None)
    
    return D

def main(args):
    dataname = args.dataname
    dataset_path = f'data/{dataname}'

    with open(f'{dataset_path}/info.json', 'r') as f:
        info = json.load(f)

    task_type = info['task_type']
    
    # Load original data for TVAE
    X_num_train, X_cat_train, y_train = src.read_pure_data(dataset_path, 'train')
    
    # Prepare training data
    train_data = []
    
    num_col_idx = info['num_col_idx']
    cat_col_idx = info['cat_col_idx']
    target_col_idx = info['target_col_idx']
    
    idx_name_mapping = info['idx_name_mapping']
    idx_name_mapping = {int(key): value for key, value in idx_name_mapping.items()}
    
    # Combine all data into DataFrame
    if X_num_train is not None and X_cat_train is not None:
        # For mixed data
        all_data = np.concatenate([X_num_train, X_cat_train, y_train], axis=1)
    elif X_num_train is not None:
        # Only numerical
        all_data = np.concatenate([X_num_train, y_train], axis=1)
    else:
        # Only categorical
        all_data = np.concatenate([X_cat_train, y_train], axis=1)
    
    train_df = pd.DataFrame(all_data)
    train_df.rename(columns=idx_name_mapping, inplace=True)
    train_df.columns = [info['column_names'][i] for i in info['num_col_idx'] + info['cat_col_idx']] + [info['column_names'][info['target_col_idx'][0]]]

    
    # Convert data types properly
    # Numerical columns
    for idx in num_col_idx:
        col_name = idx_name_mapping[idx]
        train_df[col_name] = pd.to_numeric(train_df[col_name], errors='coerce')
    
    # Categorical columns - convert to int or keep as category
    for idx in cat_col_idx:
        col_name = idx_name_mapping[idx]
        train_df[col_name] = pd.to_numeric(train_df[col_name], errors='coerce').astype('Int64')
    
    # Target column (target_col_idx might be a list)
    if isinstance(target_col_idx, list):
        target_col_idx = target_col_idx[0]
    target_col_name = idx_name_mapping[target_col_idx]
    if task_type in ['binclass', 'multiclass']:
        train_df[target_col_name] = pd.to_numeric(train_df[target_col_name], errors='coerce').astype('Int64')
    else:
        train_df[target_col_name] = pd.to_numeric(train_df[target_col_name], errors='coerce')
    
    print(f"Training TVAE on {len(train_df)} samples...")
    print(f"Data types:\n{train_df.dtypes}")
    
    # Check class distribution
    if task_type in ['binclass', 'multiclass']:
        class_counts = train_df[target_col_name].value_counts()
        print(f"\nOriginal class distribution:\n{class_counts}")
        print(f"Class proportions:\n{class_counts / len(train_df)}")
    
    # Create metadata
    metadata = SingleTableMetadata()
    metadata.detect_from_dataframe(train_df)
    
    # Initialize and train TVAE with new API
    tvae = TVAESynthesizer(
        metadata=metadata,
        epochs=args.epochs,
        verbose=True,
        enforce_min_max_values=True,
        enforce_rounding=True
    )
    tvae.fit(train_df)
    
    # Generate synthetic samples with balanced classes
    num_samples = len(train_df)
    print(f"\nGenerating {num_samples} synthetic samples...")
    
    if task_type in ['binclass', 'multiclass'] and args.balance_classes:
        # Conditional sampling for balanced classes
        print("Using conditional sampling for balanced classes...")
        
        class_counts = train_df[target_col_name].value_counts()
        num_classes = len(class_counts)
        
        # Option 1: Equal distribution
        if args.balance_strategy == 'equal':
            num_samples_per_class = num_samples // num_classes
            conditions = []
            
            for class_label in sorted(class_counts.index):
                condition = Condition(
                    num_rows=num_samples_per_class,
                    column_values={target_col_name: int(class_label)}
                )
                conditions.append(condition)
            
            syn_dfs = []
            for i, condition in enumerate(conditions):
                print(f"Generating samples for class {sorted(class_counts.index)[i]}...")
                syn_df_part = tvae.sample_from_conditions(conditions=[condition])
                syn_dfs.append(syn_df_part)
            
            syn_df = pd.concat(syn_dfs, ignore_index=True)
        
        # Option 2: Custom ratio (e.g., minority_ratio=0.3 for 30% minority class)
        elif args.balance_strategy == 'custom':
            minority_ratio = args.minority_ratio if args.minority_ratio else 0.5
            
            # Assume binary classification with class 0 (majority) and 1 (minority)
            num_minority = int(num_samples * minority_ratio)
            num_majority = num_samples - num_minority
            
            conditions = [
                Condition(num_rows=num_majority, column_values={target_col_name: 0}),
                Condition(num_rows=num_minority, column_values={target_col_name: 1})
            ]
            
            syn_dfs = []
            for i, condition in enumerate(conditions):
                class_label = 0 if i == 0 else 1
                print(f"Generating {condition.num_rows} samples for class {class_label}...")
                syn_df_part = tvae.sample_from_conditions(conditions=[condition])
                syn_dfs.append(syn_df_part)
            
            syn_df = pd.concat(syn_dfs, ignore_index=True)
        
        # Option 3: Original distribution
        else:
            syn_df = tvae.sample(num_samples)
    else:
        # Regular sampling for regression or when balance_classes is False
        syn_df = tvae.sample(num_samples)
    
    # Reorder columns to match original order
    syn_df.columns = [info['column_names'][i] for i in info['num_col_idx'] + info['cat_col_idx']] + [info['column_names'][info['target_col_idx'][0]]]
    syn_df = syn_df[info['column_names']]
    
    # Print synthetic data class distribution
    if task_type in ['binclass', 'multiclass']:
        syn_class_counts = syn_df[target_col_name].value_counts()
        print(f"\nSynthetic class distribution:\n{syn_class_counts}")
        print(f"Synthetic class proportions:\n{syn_class_counts / len(syn_df)}")
    
    # Save synthetic data
    save_path = f'synthetic/{dataname}/tvae.csv'
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    syn_df.to_csv(save_path, index=False)
    
    print(f'\nSaving sampled data to {save_path}')
    print(f"Synthetic data shape: {syn_df.shape}")

    
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='TVAE')

    parser.add_argument('--dataname', type=str, default='adult', help='Name of dataset.')
    parser.add_argument('--epochs', type=int, default=300, help='Number of training epochs for TVAE.')
    parser.add_argument('--balance_classes', action='store_false', help='Use conditional sampling for balanced classes.')
    parser.add_argument('--balance_strategy', type=str, default='equal', choices=['equal', 'custom', 'original'], 
                        help='Strategy for balancing classes: equal (50-50), custom (specify ratio), or original (keep original distribution).')
    parser.add_argument('--minority_ratio', type=float, default=0.5, 
                        help='Ratio of minority class when using custom balance strategy (e.g., 0.3 for 30% minority).')
    
    args = parser.parse_args()

    main(args)