#!/bin/bash

MODELS=("ctgan" "findiff" "smote" "stasy" "tabddpm" "tvae" "codi")

MODELS=("findiff" "tabddpm" "codi")

for model in "${MODELS[@]}"
do
    echo "Running evaluation for model: $model"
    python main.py --dataname fin2 --method "$model" --mode train
done


# # train VAE first
# python main.py --dataname fin2 --method vae --mode train --use_ratio

# # after the VAE is trained, train the diffusion model
# python main.py --dataname fin2 --method tabsyn --mode train